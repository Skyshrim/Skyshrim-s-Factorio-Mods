data.raw["locomotive"]["locomotive"].energy_per_hit_point = .000001
data.raw["locomotive"]["locomotive"].burner.effectivity = 25
data.raw["locomotive"]["locomotive"].reversing_power_modifier = 1
data.raw["locomotive"]["locomotive"].max_power = "12000kW"
data.raw["locomotive"]["locomotive"].weight = 200000
data.raw["locomotive"]["locomotive"].braking_force = 600
data.raw["locomotive"]["locomotive"].max_health = 10000
data.raw["locomotive"]["locomotive"].air_resistance = 0.075

data.raw["cargo-wagon"]["cargo-wagon"].weight = 10000
data.raw["fluid-wagon"]["fluid-wagon"].weight = 10000
data.raw["artillery-wagon"]["artillery-wagon"].weight = 10000


--[[ default values:
type = "locomotive",
    name = "locomotive",
    icon = "__base__/graphics/icons/diesel-locomotive.png",
    flags = {"placeable-neutral", "player-creation", "placeable-off-grid", "not-on-map"},
    minable = {mining_time = 1, result = "locomotive"},
    mined_sound = {filename = "__core__/sound/deconstruct-medium.ogg"},
    max_health = 1000,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-0.6, -2.6}, {0.6, 2.6}},
    selection_box = {{-1, -3}, {1, 3}},
    drawing_box = {{-1, -4}, {1, 3}},
    weight = 2000,
    max_speed = 1.2,
    max_power = "600kW",
    reversing_power_modifier = 0.6,
    braking_force = 10,
    friction_force = 0.50,
    vertical_selection_shift = -0.5,
    air_resistance = 0.0075,
    connection_distance = 3,
    joint_distance = 4,
    energy_per_hit_point = 5,
    burner =
    {
      fuel_category = "chemical",
      effectivity = 1,
      fuel_inventory_size = 3,
    },
--]]

